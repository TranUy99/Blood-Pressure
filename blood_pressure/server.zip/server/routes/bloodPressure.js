const express = require('express')
const bloodPressureRouter = express.Router()
const BloodPressure = require('../models/BloodPressure')
const verifyToken = require('../middleware/auth')

//POST BLOOD PRESSURE
bloodPressureRouter.post('/api/bloodPressure/enterBloodPressure',verifyToken,async(req,res)=>{
    
	const { sys, dia, pulse } = req.body
	try {
		const newbloodPressure = new BloodPressure({
			sys,
			dia,
			pulse,
			userId: req.userId
		})

		await newbloodPressure.save()

		res.json({ success: true, message: 'Happy!', post: newbloodPressure })
	} catch (error) {
		console.log(error)
		res.status(500).json({ success: false, message: 'Internal server error' })
	}
});

bloodPressureRouter.get('/api/bloodPressure/getBloodPressure', verifyToken, async (req, res) => {
	try {
		const bloodPressure = await BloodPressure.find({ userId: req.userId })
		res.json({ success: true, bloodPressure })
	} catch (error) {
		console.log(error)
		res.status(500).json({ success: false, message: 'Internal server error' })
	}
})

module.exports = bloodPressureRouter;