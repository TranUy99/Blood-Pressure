const express = require('express')
const authRouter = express.Router();
const bcryptjs = require("bcryptjs");
const jwt = require('jsonwebtoken')
const User = require('../models/User')
const verifyToken = require('../middleware/auth')

//SIGN UP
authRouter.post("/api/register", async (req, res) => {
	const { username, email,password } = req.body

	// Simple validation
	if (!username || !password||!email)
		return res
			.status(400)
			.json({ success: false, message: 'Missing username and/or password' })

	try {
		// Check for existing user
		const user = await User.findOne({ email })

		if (user)
			return res
				.status(400)
				.json({ success: false, message: 'Email already taken' })

		// All good
		const hashedPassword = await await bcryptjs.hash(password, 8);
		const newUser = new User({ username, password: hashedPassword })
		await newUser.save()

		// Return token
		const token = jwt.sign(
			{ userId: newUser._id },
			process.env.ACCESS_TOKEN_SECRET
		)

		res.json({
			success: true,
			message: 'User created successfully',
			token
		})
	} catch (error) {
		console.log(error)
		res.status(500).json({ success: false, message: 'Internal server error' })
	}
  });
  
  // Sign In Route
  // Exercise
  authRouter.post("/api/login", async (req, res) => {
	const { email, password } = req.body

	// Simple validation
	if (!email || !password)
		return res
			.status(400)
			.json({ success: false, message: 'Missing username and/or password' })

	try {
		// Check for existing user
		const user = await User.findOne({ email })
		if (!user)
			return res
				.status(400)
				.json({ success: false, message: 'Incorrect username or password' })

		// Username found
		const passwordValid = await bcryptjs.compare(password, user.password);
		if (!passwordValid)
			return res
				.status(400)
				.json({ success: false, message: 'Incorrect username or password' })

		// All good
		// Return token
		const token = jwt.sign(
			{ userId: user._id },
			process.env.ACCESS_TOKEN_SECRET
		)

		res.json({
			success: true,
			message: 'User logged in successfully',
			token
		})
	} catch (error) {
		console.log(error)
		res.status(500).json({ success: false, message: 'Internal server error' })
	}
  });
  
  authRouter.post("/tokenIsValid", async (req, res) => {
	try {
	  const token = req.header("Authorization");
	  if (!token) return res.json(false);
	  const verified = jwt.verify(token, process.env.ACCESS_TOKEN_SECRET);
	  if (!verified) return res.json(false);
  
	  const user = await User.findById(verified.id);
	  if (!user) return res.json(false);
	  res.json(true);
	} catch (e) {
	  res.status(500).json({ error: e.message });
	}
  });
  
  // get user data
  authRouter.get("/", verifyToken, async (req, res) => {
	const user = await User.findById(req.user);
	res.json({ ...user._doc, token: req.token });
  });
  
  
  

module.exports = authRouter;