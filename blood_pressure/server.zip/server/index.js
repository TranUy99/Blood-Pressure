const express = require("express");
const cors = require('cors')
const mongoose = require("mongoose");
require('dotenv').config()
// IMPORTS FROM OTHER FILES
const authRouter = require("./routes/auth");
const bloodPressureRouter = require("./routes/bloodPressure");
// const bloodPrussure = require("./routes/bloodPressure");


// INIT
const PORT = process.env.PORT || 3000;
const app = express();
const DB =
  "mongodb+srv://uy:uy123@cluster0.m776gwd.mongodb.net/?retryWrites=true&w=majority";

// middleware
app.use(express.json());
app.use(cors());
app.use(authRouter);
app.use(bloodPressureRouter);

// Connections
mongoose
  .connect(DB)
  .then(() => {
    console.log("Connection Successful");
  })
  .catch((e) => {
    console.log(e);
  });

app.listen(PORT, "0.0.0.0", () => {
  console.log(`connected at port ${PORT}`);
});