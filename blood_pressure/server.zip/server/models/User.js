const mongoose = require('mongoose')

const Schema = mongoose.Schema

const User = new Schema({
    username: {type: String, required: true, default: 'user0'},
    email: {type: String, required: true, default: 'user0@gmail.com'},
    password:{type:String, require:true},
    address:{type: String, },
    phonenumber: {type: String,},
    gender:{type:Boolean,},
    image: {type: String},
   
})

module.exports = mongoose.model('user', User)